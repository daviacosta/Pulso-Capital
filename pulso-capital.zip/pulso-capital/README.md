# Pulso Capital

Site de investimentos que transforma as notícias das empresas da B3 em um "monitor cardíaco" do mercado: cada notícia vira um batimento. Tem feed de notícias, aba Agro, blog, ranking de dividendos e valorização, agenda de balanços, painel por empresa, cadastro de visitantes e área do administrador.

## Como funciona na Vercel

```
Visitante ──> Vercel (site + funções /api)
                 │            └── Upstash Redis (cadastros e posts do painel)
                 └── data/*.json  <── GitHub Actions roda o robô 3x por dia útil e faz commit
                                       (cada commit gera um novo deploy automático)
```

```
index.html          site (todas as abas)
admin.html          área do administrador (/admin): cadastros e posts do blog
config.js           liga os recursos que usam a API
api/cadastro.js     cria, atualiza e exclui cadastros (com consentimento LGPD e anti-spam)
api/cadastros.js    lista e exporta cadastros em CSV (só administrador)
api/posts.js        posts do blog escritos pelo painel
lib/redis.js        conexão com o Upstash Redis (sem dependências)
data/               notícias, painel, ranking, agro e blog (atualizados pelo robô)
robo/robo.py        o robô
.github/workflows/  agenda do robô
vercel.json         cache, cabeçalhos de segurança e URLs limpas
```

## Publicar em 6 passos

1. **GitHub:** crie um repositório (pode ser privado) e envie todo o conteúdo desta pasta para a branch `main`.
2. **Vercel:** em *Add New → Project*, importe o repositório. Em *Framework Preset* escolha **Other**, deixe *Build Command* e *Output Directory* vazios e clique em **Deploy**. O site já fica no ar, só sem cadastro e sem posts pelo painel.
3. **Banco de dados:** no projeto da Vercel, abra **Storage → Create Database → Upstash (Redis)**, escolha o plano gratuito e conecte ao projeto. A Vercel cria sozinha as variáveis de conexão.
4. **Senha do administrador:** em **Settings → Environment Variables**, crie `ADMIN_TOKEN` com uma senha longa (mínimo de 12 caracteres, de preferência mais de 24). Depois, em *Deployments*, clique em **Redeploy**.
5. **Robô:** no GitHub, abra **Settings → Actions → General → Workflow permissions** e marque **Read and write permissions**. Em **Settings → Secrets and variables → Actions**, crie se quiser:
   - `ANTHROPIC_API_KEY`: resumos escritos pelo Claude e o post "Resumo da semana" toda sexta.
   - `BRAPI_TOKEN`: cotações e mini gráficos nos cards (token gratuito em brapi.dev).
6. **Primeira rodada:** em **Actions → Robô Pulso Capital → Run workflow**. A partir daí ele roda sozinho às 7h40, 11h40 e 17h40 (Brasília) nos dias úteis.

Domínio próprio: **Settings → Domains** no projeto da Vercel.

## Se aparecer "Cadastro indisponível no momento"

Abra `seu-site.vercel.app/api/status`. A página mostra se o banco foi encontrado, se a conexão funciona e se o `ADMIN_TOKEN` existe, sem revelar nenhum valor. As causas mais comuns:
1. **Banco não conectado ao projeto:** em *Storage*, o banco precisa aparecer como conectado a **este** projeto, com o ambiente *Production* marcado.
2. **Faltou o Redeploy:** variáveis novas só valem para deploys feitos depois delas. Vá em *Deployments → ⋯ → Redeploy*.
3. **Banco de outro tipo:** o projeto aceita tanto o Upstash (variáveis `KV_REST_API_*` ou `UPSTASH_REDIS_REST_*`, com ou sem prefixo) quanto o Redis tradicional (`REDIS_URL`).

## Área do administrador

Acesse `seu-site.vercel.app/admin` e entre com o `ADMIN_TOKEN`.
- **Cadastros:** totais, divisão por perfil, tabela completa, planilha CSV e botão para copiar os e-mails de quem pediu o briefing.
- **Posts do blog:** escrever, editar e excluir posts. Eles aparecem no site em até 1 minuto, sem novo deploy.

A página não aparece em buscadores (`noindex`) e o token fica só na aba aberta do navegador.

## Cadastro e LGPD

- O visitante só envia os dados depois de marcar a concordância.
- Ao se cadastrar, o navegador dele guarda uma chave secreta; com ela, ele edita ou exclui o próprio cadastro em **Minha conta**. A chave é guardada no banco apenas como hash.
- Há proteção contra robôs de spam (campo armadilha e limite de tentativas por IP).
- O envio do briefing por e-mail ainda é manual: exporte a lista no painel e dispare pela ferramenta que preferir.

## Rodar no computador

```bash
npm i -g vercel
vercel link          # liga a pasta ao projeto
vercel env pull      # baixa as variáveis (banco e ADMIN_TOKEN)
vercel dev           # http://localhost:3000
```

Robô manual: `pip install -r robo/requirements.txt && python robo/robo.py`

## Ajustes rápidos

- Fontes de notícias: `FEEDS` e `FEEDS_AGRO` em `robo/robo.py`.
- Empresas monitoradas: `robo/empresas.json` (marque `"ambiguo": true` em nomes que também são palavras comuns, como "Vale").
- Ranking: `data/ranking.json`.
- Horário do pregão e feriados: `pregao` e `feriados` em `data/painel.json`.
- Foto na aba Agro (em vez das ilustrações que mudam a cada hora): coloque a imagem na pasta e preencha `"foto": "/agro.jpg"` em `meta` de `data/agro.json`.

Conteúdo informativo, gerado automaticamente a partir de fontes públicas. Não é recomendação de investimento.
