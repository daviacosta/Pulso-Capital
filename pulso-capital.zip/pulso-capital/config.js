// Liga os recursos que dependem das funções da Vercel (cadastro e posts do painel).
window.PULSO_API = location.protocol.startsWith("http");
