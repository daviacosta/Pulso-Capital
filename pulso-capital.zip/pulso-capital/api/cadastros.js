// GET /api/cadastros  (somente administrador: cabeçalho Authorization: Bearer ADMIN_TOKEN)
//   ?formato=csv  → planilha CSV
import { redis, isAdmin, configurado } from "../lib/redis.js";

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (!isAdmin(req)) return res.status(401).json({ erro: "Acesso negado." });
  if (!configurado()) return res.status(503).json({ erro: "Banco de dados não configurado." });
  if (req.method !== "GET") { res.setHeader("Allow", "GET"); return res.status(405).json({ erro: "Método não permitido." }); }
  const raw = (await redis("HGETALL", "cadastros")) || [];
  const itens = [];
  for (let i = 1; i < raw.length; i += 2) { const { chaveHash, ...d } = JSON.parse(raw[i]); itens.push(d); }
  itens.sort((a, b) => (b.criadoEm || "").localeCompare(a.criadoEm || ""));
  if (req.query?.formato === "csv") {
    const esc = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const linhas = [["Nome", "E-mail", "Perfil", "Experiência", "Interesses", "Briefing", "Cadastro"],
      ...itens.map((x) => [x.nome, x.email, x.perfil, x.experiencia, (x.interesses || []).join("; "), x.briefing ? "Sim" : "Não", x.criadoEm])];
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", 'attachment; filename="cadastros-pulso-capital.csv"');
    return res.status(200).send("﻿" + linhas.map((l) => l.map(esc).join(";")).join("\n"));
  }
  return res.status(200).json({ total: itens.length, itens });
}
