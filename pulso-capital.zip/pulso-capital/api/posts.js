// GET    /api/posts          → posts publicados pelo painel (público)
// POST   /api/posts          → cria ou edita um post (administrador)
// DELETE /api/posts?slug=... → exclui um post (administrador)
// Os posts do arquivo data/posts.json (robô e artigos iniciais) continuam valendo; o site junta as duas fontes.
import { redis, isAdmin, corpo, limpa, configurado } from "../lib/redis.js";

const CATS = ["Análise", "Educação", "Resumo da semana", "Opinião"];
const slugify = (t) => t.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60) || "post";

export default async function handler(req, res) {
  if (!configurado()) { if (req.method === "GET") return res.status(200).json({ itens: [] }); return res.status(503).json({ erro: "Banco de dados não configurado." }); }
  try {
    if (req.method === "GET") {
      res.setHeader("Cache-Control", "public, s-maxage=60, stale-while-revalidate=300");
      const raw = (await redis("HGETALL", "posts")) || [];
      const itens = []; for (let i = 1; i < raw.length; i += 2) itens.push(JSON.parse(raw[i]));
      itens.sort((a, b) => (b.data || "").localeCompare(a.data || ""));
      return res.status(200).json({ itens });
    }
    res.setHeader("Cache-Control", "no-store");
    if (!isAdmin(req)) return res.status(401).json({ erro: "Acesso negado." });
    if (req.method === "POST") {
      const b = corpo(req), titulo = limpa(b.titulo, 140), texto = String(b.corpo || "").slice(0, 40000).trim();
      if (!titulo) return res.status(400).json({ erro: "Escreva um título." });
      if (texto.split(/\s+/).length < 20) return res.status(400).json({ erro: "O texto está muito curto." });
      const slug = b.slug ? slugify(String(b.slug)) : `${slugify(titulo)}-${new Date().toISOString().slice(0, 10)}`;
      const antigo = await redis("HGET", "posts", slug);
      const doc = {
        slug, titulo, corpo: texto, resumo: limpa(b.resumo, 280),
        categoria: CATS.includes(b.categoria) ? b.categoria : "Análise",
        tickers: (Array.isArray(b.tickers) ? b.tickers : []).filter((t) => /^[A-Z]{4}\d{1,2}$/.test(t)).slice(0, 10),
        autor: limpa(b.autor, 60) || "Pulso Capital",
        data: antigo ? JSON.parse(antigo).data : new Date().toISOString(), editadoEm: new Date().toISOString(),
      };
      await redis("HSET", "posts", slug, JSON.stringify(doc));
      return res.status(antigo ? 200 : 201).json({ ok: true, post: doc });
    }
    if (req.method === "DELETE") {
      const slug = slugify(String(req.query?.slug || ""));
      await redis("HDEL", "posts", slug);
      return res.status(200).json({ ok: true });
    }
    res.setHeader("Allow", "GET, POST, DELETE");
    return res.status(405).json({ erro: "Método não permitido." });
  } catch (e) {
    return res.status(e.status || 500).json({ erro: "Erro no servidor. Tente de novo." });
  }
}
