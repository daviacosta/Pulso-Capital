// GET /api/status → mostra se o banco e a senha do administrador estão configurados (sem expor valores).
import { diagnostico, configurado, redis } from "../lib/redis.js";

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  const d = diagnostico();
  let conexao = "não testada";
  if (configurado()) {
    try { await redis("PING"); conexao = "ok"; }
    catch (e) { conexao = "falhou: " + String(e.message || e).slice(0, 120); }
  }
  const pronto = conexao === "ok";
  res.status(200).json({
    cadastro: pronto ? "funcionando" : "indisponível",
    banco: d.banco,
    conexao,
    variaveisEncontradas: d.variaveis,
    adminToken: d.adminToken,
    oQueFazer: pronto
      ? (d.adminToken === "definido" ? "Tudo certo." : "Crie a variável ADMIN_TOKEN (12+ caracteres) e faça Redeploy para usar /admin.")
      : "No projeto da Vercel: Storage → conecte um banco Redis (Upstash) a este projeto, marcando Production. Depois vá em Deployments → ⋯ → Redeploy. Variáveis novas só valem para deploys feitos depois delas.",
  });
}
