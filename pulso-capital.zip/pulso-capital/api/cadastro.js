// POST   /api/cadastro  → cria ou atualiza o cadastro (atualizar exige a chave recebida no primeiro envio)
// DELETE /api/cadastro  → exclui o cadastro (e-mail + chave), atendendo ao direito de exclusão da LGPD
import { redis, limitar, corpo, novaChave, hash, limpa, configurado } from "../lib/redis.js";

const PERFIS = ["Conservador", "Moderado", "Arrojado"];
const EXPERIENCIAS = ["Estou começando", "Invisto há até 3 anos", "Invisto há mais de 3 anos"];
const INTERESSES = ["Dividendos", "Crescimento", "Small caps", "Bancos", "Commodities", "Balanços"];
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (!configurado()) return res.status(503).json({ erro: "Cadastro indisponível no momento. Tente mais tarde." });
  try {
    const b = corpo(req);
    if (req.method === "POST") {
      if (b.site) return res.status(200).json({ ok: true });            // armadilha para robôs de spam
      if (!(await limitar(req, "cad"))) return res.status(429).json({ erro: "Muitas tentativas. Aguarde alguns minutos." });
      const email = limpa(b.email, 120).toLowerCase(), nome = limpa(b.nome, 80);
      if (nome.length < 2) return res.status(400).json({ erro: "Escreva seu nome." });
      if (!EMAIL.test(email)) return res.status(400).json({ erro: "Confira o e-mail." });
      if (!PERFIS.includes(b.perfil)) return res.status(400).json({ erro: "Escolha um perfil." });
      if (b.consentimento !== true) return res.status(400).json({ erro: "É preciso concordar com o uso dos dados." });

      const atual = await redis("HGET", "cadastros", email);
      const antigo = atual ? JSON.parse(atual) : null;
      let chave = b.chave;
      if (antigo) {
        if (!chave || hash(chave) !== antigo.chaveHash) return res.status(409).json({ erro: "Este e-mail já está cadastrado." });
      } else chave = novaChave();

      const agora = new Date().toISOString();
      const doc = {
        nome, email, perfil: b.perfil,
        experiencia: EXPERIENCIAS.includes(b.experiencia) ? b.experiencia : EXPERIENCIAS[0],
        interesses: (Array.isArray(b.interesses) ? b.interesses : []).filter((i) => INTERESSES.includes(i)),
        briefing: b.briefing === true, consentimento: true,
        favoritos: (Array.isArray(b.favoritos) ? b.favoritos : []).filter((t) => /^[A-Z]{4}\d{1,2}$/.test(t)).slice(0, 50),
        criadoEm: antigo?.criadoEm || agora, atualizadoEm: agora, chaveHash: hash(chave),
      };
      await redis("HSET", "cadastros", email, JSON.stringify(doc));
      return res.status(antigo ? 200 : 201).json({ ok: true, chave });
    }
    if (req.method === "DELETE") {
      const email = limpa(b.email, 120).toLowerCase();
      const atual = await redis("HGET", "cadastros", email);
      if (!atual) return res.status(200).json({ ok: true });
      if (!b.chave || hash(b.chave) !== JSON.parse(atual).chaveHash) return res.status(403).json({ erro: "Não foi possível confirmar o cadastro." });
      await redis("HDEL", "cadastros", email);
      return res.status(200).json({ ok: true });
    }
    res.setHeader("Allow", "POST, DELETE");
    return res.status(405).json({ erro: "Método não permitido." });
  } catch (e) {
    return res.status(e.status || 500).json({ erro: "Não foi possível salvar agora. Tente de novo em instantes." });
  }
}
