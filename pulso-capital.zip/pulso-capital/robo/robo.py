#!/usr/bin/env python3
"""
Robô do Pulso Capital
---------------------
1. Lê os feeds RSS de portais de economia (config em FEEDS).
2. Separa as matérias que citam empresas listadas na B3 (lista em empresas.json).
3. Resume cada matéria em um card: título, resumo, até 3 pontos, impacto e categoria.
   - Com a variável ANTHROPIC_API_KEY definida, o resumo é feito pelo Claude.
   - Sem a chave, usa um resumo simples a partir do próprio RSS.
4. Grava data/news.json (mantém os 60 mais recentes) e atualiza data/painel.json.

Uso:  python robo/robo.py
"""
from __future__ import annotations

import html
import json
import os
import re
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import feedparser

RAIZ = Path(__file__).resolve().parent.parent
DADOS = RAIZ / "data"
NEWS = DADOS / "news.json"
PAINEL = DADOS / "painel.json"
EMPRESAS = Path(__file__).resolve().parent / "empresas.json"

BRT = timezone(timedelta(hours=-3))
MAX_CARDS = 300
NOVOS_POR_RODADA = 12
JANELA_HORAS = 48

FEEDS = {
    "InfoMoney": "https://www.infomoney.com.br/mercados/feed/",
    "InfoMoney Negócios": "https://www.infomoney.com.br/negocios/feed/",
    "Money Times": "https://www.moneytimes.com.br/feed/",
    "Exame": "https://exame.com/invest/feed/",
    "E-Investidor": "https://einvestidor.estadao.com.br/feed/",
    "Suno": "https://www.suno.com.br/noticias/feed/",
    "Seu Dinheiro": "https://www.seudinheiro.com/feed/",
    "InvestNews": "https://investnews.com.br/feed/",
    "BP Money": "https://bpmoney.com.br/feed/",
    "Times Brasil": "https://timesbrasil.com.br/feed/",
    "Investidor10": "https://investidor10.com.br/noticias/feed/",
    "Acionista": "https://acionista.com.br/feed/",
}

FEEDS_AGRO = {
    "Canal Rural": "https://www.canalrural.com.br/feed/",
    "Forbes Agro": "https://forbes.com.br/forbes-agro/feed/",
    "Agrolink": "https://www.agrolink.com.br/rss/noticias.xml",
    "Compre Rural": "https://comprerural.com/feed/",
    "Money Times Agro": "https://www.moneytimes.com.br/agronegocio/feed/",
}
TEMAS_AGRO = [("Clima", r"chuva|seca|clima|geada|el ni|la ni|plantio"), ("Preços", r"pre[cç]o|cota[cç]|chicago|bushel|arroba|saca"),
              ("Exportação", r"export|embarque|china|porto"), ("Safra", r"safra|conab|usda|colheita|produ[cç][aã]o"),
              ("Crédito", r"cr[eé]dito|recupera[cç][aã]o judicial|d[ií]vida|juros|plano safra"), ("Pecuária", r"boi|gado|carne|frigor|pecu")]
AGRO_RX = r"soja|milho|safra|agro|boi|gado|caf[eé]|a[cç][uú]car|etanol|algod|trigo|conab|usda|fertiliz|lavoura|plantio|colheita"
MAX_AGRO = 120

CATEGORIAS = ["Resultado", "Prévia", "Rating", "Dividendos", "Reestruturação",
              "Corporativo", "Dívida", "Mercado", "Análise", "Fato relevante"]

POSITIVAS = ["lucro sobe", "alta", "recorde", "supera", "acima do esperado", "recompra",
             "dividendos", "jcp", "eleva", "positiva", "dispara", "aprova", "upgrade"]
NEGATIVAS = ["prejuízo", "queda", "abaixo do esperado", "recua", "rebaixa", "despenca",
             "recuperação judicial", "multa", "investigação", "corta", "negativa", "tomba"]


# ---------- utilidades ----------
def limpar(txt: str) -> str:
    txt = re.sub(r"<[^>]+>", " ", txt or "")
    return re.sub(r"\s+", " ", html.unescape(txt)).strip()


def ler_json(p: Path, padrao):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return padrao


def gravar_json(p: Path, dado) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(dado, ensure_ascii=False, indent=1), encoding="utf-8")


def slug(txt: str) -> str:
    txt = re.sub(r"[^a-z0-9]+", "-", txt.lower())
    return txt.strip("-")[:40]


# ---------- coleta ----------
def coletar(feeds: dict | None = None) -> list[dict]:
    limite = datetime.now(timezone.utc) - timedelta(hours=JANELA_HORAS)
    materias = []
    for fonte, url in (feeds or FEEDS).items():
        try:
            feed = feedparser.parse(url, agent="PulsoCapital/1.0 (+https://github.com)")
        except Exception as e:  # feed fora do ar não derruba o robô
            print(f"[aviso] {fonte}: {e}", file=sys.stderr)
            continue
        for e in feed.entries:
            quando = e.get("published_parsed") or e.get("updated_parsed")
            dt = datetime.fromtimestamp(time.mktime(quando), timezone.utc) if quando else datetime.now(timezone.utc)
            if dt < limite:
                continue
            materias.append({
                "fonte": fonte,
                "url": e.get("link", ""),
                "titulo": limpar(e.get("title", "")),
                "texto": limpar(e.get("summary", "") or e.get("description", "")),
                "data": dt.astimezone(BRT).isoformat(timespec="minutes"),
            })
        print(f"[ok] {fonte}: {len(feed.entries)} itens no feed")
    return materias


def identificar_empresa(m: dict, empresas: list[dict]) -> dict | None:
    alvo = f"{m['titulo']} {m['texto']}"
    # 1º: ticker explícito, ex.: (PETR4)
    for tk in re.findall(r"\b([A-Z]{4}(?:3|4|5|6|11))\b", alvo):
        for emp in empresas:
            if tk in emp["tickers"]:
                return {**emp, "ticker": tk}
    # 2º: nome da empresa no título (respeitando maiúsculas).
    #    Nomes que também são palavras comuns ("Vale", "Rumo", "Vamos"...) estão marcados
    #    como "ambiguo" e só contam com ticker escrito ou com contexto de mercado.
    titulo = m["titulo"]
    contexto = re.search(r"\b(ações|ação|papéis|lucro|prejuízo|balanço|dividendos|JCP|trimestre|Ibovespa|bolsa|B3)\b", alvo, re.I)
    for emp in empresas:
        achou = any(re.search(rf"(?<![\wÀ-ÿ]){re.escape(n)}(?![\wÀ-ÿ])", titulo) for n in emp["nomes"])
        if achou and (not emp.get("ambiguo") or contexto):
            return {**emp, "ticker": emp["tickers"][0]}
    return None


# ---------- resumo ----------
def resumo_simples(m: dict) -> dict:
    t = f"{m['titulo']} {m['texto']}".lower()
    pos = sum(w in t for w in POSITIVAS)
    neg = sum(w in t for w in NEGATIVAS)
    impacto = "positivo" if pos > neg else "negativo" if neg > pos else "neutro"
    cat = "Mercado"
    for chave, c in [("trimestre", "Resultado"), ("3t", "Resultado"), ("4t", "Resultado"),
                     ("dividend", "Dividendos"), ("jcp", "Dividendos"), ("rating", "Rating"),
                     ("recupera", "Reestruturação"), ("debênture", "Dívida"), ("recompra", "Corporativo"),
                     ("fato relevante", "Fato relevante"), ("preço-alvo", "Análise")]:
        if chave in t:
            cat = c
            break
    frases = re.split(r"(?<=[.!?])\s+", m["texto"])
    resumo = " ".join(frases[:2])[:280]
    return {"titulo": m["titulo"][:110], "resumo": resumo, "pontos": [],
            "impacto": impacto, "categoria": cat}


def resumo_claude(m: dict, empresa: str) -> dict | None:
    chave = os.environ.get("ANTHROPIC_API_KEY")
    if not chave:
        return None
    try:
        import anthropic
    except ImportError:
        return None
    cliente = anthropic.Anthropic(api_key=chave)
    pedido = f"""Você resume notícias de economia para investidores brasileiros.
Empresa: {empresa}
Título original: {m['titulo']}
Texto do RSS: {m['texto'][:2500]}

Responda APENAS um JSON com as chaves:
"titulo" (até 90 caracteres, reescrito com suas palavras),
"resumo" (1 a 2 frases, suas palavras, sem copiar o texto),
"pontos" (lista de até 3 frases curtas com números concretos, se houver),
"impacto" ("positivo", "negativo" ou "neutro" para a ação),
"categoria" (uma de: {', '.join(CATEGORIAS)})."""
    try:
        r = cliente.messages.create(
            model=os.environ.get("RADAR_MODELO", "claude-haiku-5-5"),
            max_tokens=500,
            messages=[{"role": "user", "content": pedido}],
        )
        txt = r.content[0].text
        dado = json.loads(txt[txt.find("{"): txt.rfind("}") + 1])
        if dado.get("impacto") not in ("positivo", "negativo", "neutro"):
            dado["impacto"] = "neutro"
        return dado
    except Exception as e:
        print(f"[aviso] Claude falhou, usando resumo simples: {e}", file=sys.stderr)
        return None


# ---------- painel ----------
def cotacoes(tickers: list[str]) -> None:
    """Opcional: com BRAPI_TOKEN definido, busca preço e variação do dia em brapi.dev
    e grava data/cotacoes.json, acumulando até 30 fechamentos por ação."""
    token = os.environ.get("BRAPI_TOKEN")
    if not token or not tickers:
        return
    import urllib.request
    arq = DADOS / "cotacoes.json"
    atual = ler_json(arq, {"itens": {}})
    hoje = datetime.now(BRT).date().isoformat()
    for tk in sorted(set(tickers))[:40]:
        try:
            with urllib.request.urlopen(f"https://brapi.dev/api/quote/{tk}?token={token}", timeout=15) as resp:
                r = json.loads(resp.read().decode())["results"][0]
            preco, var = r.get("regularMarketPrice"), r.get("regularMarketChangePercent")
            if preco is None:
                continue
            item = atual["itens"].get(tk, {"serie": []})
            serie = [p for p in item.get("serie", []) if p[0] != hoje] + [[hoje, preco]]
            atual["itens"][tk] = {"preco": preco, "variacao": var, "serie": serie[-30:]}
        except Exception as e:
            print(f"[aviso] cotação {tk}: {e}", file=sys.stderr)
    atual["atualizadoEm"] = datetime.now(BRT).isoformat(timespec="minutes")
    gravar_json(arq, atual)


def briefing(itens: list[dict]) -> dict:
    hoje = [i for i in itens if i.get("data", "")[:10] == datetime.now(BRT).date().isoformat()] or itens[:5]
    pos = sum(i.get("impacto") == "positivo" for i in hoje)
    neg = sum(i.get("impacto") == "negativo" for i in hoje)
    tom = "positivo" if pos > neg else "negativo" if neg > pos else "equilibrado"
    texto = (f"O noticiário das empresas listadas está com tom {tom}: {pos} notícias boas e {neg} ruins "
             f"entre as {len(hoje)} mais recentes.")
    return {"data": datetime.now(BRT).isoformat(timespec="minutes"), "texto": texto,
            "pontos": [f"{i['ticker']}: {i['titulo']}" for i in hoje[:3]]}


def atualizar_painel(n_cards: int, itens: list[dict] | None = None) -> None:
    painel = ler_json(PAINEL, {})
    if itens:
        painel["briefing"] = briefing(itens)
    hoje = datetime.now(BRT).date()
    painel["agenda"] = [a for a in painel.get("agenda", [])
                        if a.get("data", "9999") >= (hoje - timedelta(days=2)).isoformat()]
    painel["atualizadoEm"] = datetime.now(BRT).isoformat(timespec="minutes")
    painel["cards"] = n_cards
    gravar_json(PAINEL, painel)


# ---------- agro ----------
def atualizar_agro(empresas: list[dict]) -> int:
    arq = DADOS / "agro.json"
    agro = ler_json(arq, {"meta": {}, "itens": []})
    itens = agro.get("itens", [])
    vistos = {i.get("url") for i in itens}
    novos = []
    for m in coletar(FEEDS_AGRO):
        alvo = f"{m['titulo']} {m['texto']}"
        if m["url"] in vistos or not re.search(AGRO_RX, alvo, re.I):
            continue
        emp = identificar_empresa(m, empresas)
        card = resumo_claude(m, emp["empresa"] if emp else "setor de agronegócio") or resumo_simples(m)
        tema = next((t for t, rx in TEMAS_AGRO if re.search(rx, alvo, re.I)), "Safra")
        card.update({"id": f"{m['data'][:10]}-{slug(m['titulo'])}", "tema": "Empresas" if emp else tema,
                     "fonte": m["fonte"], "url": m["url"], "data": m["data"]})
        card.pop("categoria", None)
        if emp:
            card["ticker"] = emp["ticker"]
        novos.append(card); vistos.add(m["url"])
        if len(novos) >= 6:
            break
    agro["itens"] = sorted(novos + itens, key=lambda x: x.get("data", ""), reverse=True)[:MAX_AGRO]
    agro.setdefault("meta", {})["atualizadoEm"] = datetime.now(BRT).isoformat(timespec="minutes")
    gravar_json(arq, agro)
    return len(novos)


# ---------- blog: resumo da semana (sexta, rodada da tarde, com ANTHROPIC_API_KEY) ----------
def resumo_semanal(itens: list[dict]) -> None:
    agora = datetime.now(BRT)
    if agora.weekday() != 4 or agora.hour < 16 or not os.environ.get("ANTHROPIC_API_KEY"):
        return
    arq = DADOS / "posts.json"
    posts = ler_json(arq, {"itens": []})
    slug_post = f"semana-{agora.date().isoformat()}"
    if any(p.get("slug", "").startswith(slug_post) for p in posts["itens"]):
        return
    semana = [i for i in itens if i.get("data", "") >= (agora - timedelta(days=5)).isoformat()][:40]
    if len(semana) < 3:
        return
    try:
        import anthropic
        lista = "\n".join(f"- {i['data'][:10]} {i['ticker']} ({i.get('impacto')}): {i['titulo']}. {i.get('resumo', '')}" for i in semana)
        pedido = f"""Escreva, em português do Brasil, o post "Resumo da semana" de um site de investimentos sobre a bolsa brasileira,
com base SOMENTE nestas notícias (não invente números):
{lista}

Responda APENAS um JSON com: "titulo" (até 110 caracteres), "resumo" (1–2 frases), "tickers" (até 6 mais citados),
"corpo" (500 a 700 palavras; parágrafos separados por linha em branco; subtítulos com "## "; listas com "- "; cite ações como $TICKER;
sem recomendar compra ou venda; termine com o que acompanhar na próxima semana)."""
        r = anthropic.Anthropic().messages.create(model=os.environ.get("RADAR_MODELO", "claude-haiku-5-5"), max_tokens=2500,
                                                  messages=[{"role": "user", "content": pedido}])
        txt = r.content[0].text
        d = json.loads(txt[txt.find("{"): txt.rfind("}") + 1])
        post = {"slug": f"{slug_post}-{slug(d['titulo'])[:30]}", "titulo": d["titulo"], "resumo": d.get("resumo", ""),
                "corpo": d["corpo"], "tickers": d.get("tickers", [])[:6], "categoria": "Resumo da semana",
                "autor": "Robô Pulso", "data": agora.isoformat(timespec="minutes")}
        posts["itens"] = [post] + posts["itens"]
        gravar_json(arq, posts)
        print("[blog] resumo da semana publicado")
    except Exception as e:
        print(f"[aviso] resumo semanal não gerado: {e}", file=sys.stderr)


# ---------- principal ----------
def main() -> None:
    empresas = ler_json(EMPRESAS, [])
    atual = ler_json(NEWS, {"itens": []})
    itens = atual.get("itens", atual if isinstance(atual, list) else [])
    vistos = {i.get("url") for i in itens} | {i.get("id") for i in itens}

    novos = []
    for m in coletar():
        if m["url"] in vistos or not m["titulo"]:
            continue
        emp = identificar_empresa(m, empresas)
        if not emp:
            continue
        card = resumo_claude(m, emp["empresa"]) or resumo_simples(m)
        card.update({
            "id": f"{m['data'][:10]}-{emp['ticker'].lower()}-{slug(m['titulo'])}",
            "ticker": emp["ticker"], "empresa": emp["empresa"],
            "fonte": m["fonte"], "url": m["url"], "data": m["data"],
        })
        novos.append(card)
        vistos.add(m["url"])
        if len(novos) >= NOVOS_POR_RODADA:
            break

    itens = sorted(novos + itens, key=lambda x: x.get("data", ""), reverse=True)[:MAX_CARDS]
    gravar_json(NEWS, {"itens": itens})
    atualizar_painel(len(itens), itens)
    recentes = [i["ticker"] for i in itens if i.get("data", "") >= (datetime.now(BRT) - timedelta(days=7)).isoformat()]
    cotacoes(recentes)
    n_agro = atualizar_agro(empresas)
    resumo_semanal(itens)
    embutido = {"news": {"itens": itens}, "painel": ler_json(PAINEL, {}),
                "ranking": ler_json(DADOS / "ranking.json", None),
                "cotacoes": ler_json(DADOS / "cotacoes.json", None),
                "posts": ler_json(DADOS / "posts.json", {"itens": []}).get("itens", []),
                "agro": ler_json(DADOS / "agro.json", None)}
    (DADOS / "dados.js").write_text("window.RADAR_DADOS = " + json.dumps(embutido, ensure_ascii=False) + ";\n", encoding="utf-8")
    print(f"[fim] {len(novos)} cards novos · {len(itens)} no feed · {n_agro} notícias do agro")


if __name__ == "__main__":
    main()
